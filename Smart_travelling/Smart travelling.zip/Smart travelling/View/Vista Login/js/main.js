function Show(){
  $('.struttura').show();
  }

function DShow(){
  $('.struttura').hide();
  }
